import React from "react";

function Error() {
  return (
    <div>
      <h1>This page is not available</h1>
    </div>
  );
}

export default Error;
